# mapa.py
import streamlit as st
import streamlit_folium
import folium
import sqlite3
from geopy.geocoders import Nominatim


def obter_coordenadas(endereco):
    geolocator = Nominatim(user_agent="my_geocoder")
    location = geolocator.geocode(endereco)

    if location:
        return location.latitude, location.longitude
    else:
        return None


def exibir_mapa_reclamacoes():
    con = sqlite3.connect('denuncia.db')
    cur = con.cursor()

    st.header("Historico de denuncias")

    mapa = folium.Map(location=[-15.6010, -56.0974],
                      zoom_start=12)

    '''endereco = cur.execute("select endereco from local")
    endereco_local = endereco.fetchall()

    cont_endereco = cur.execute("select count(endereco) from local")
    cont_endereco = cont_endereco.fetchone()[0]'''
    coordenadas = [
        [-15.6010, -56.0974],  # Exemplo 1
        [-15.6020, -56.0980],  # Exemplo 2
        [-15.6030, -56.0990],  # Exemplo 3
        # Adicione mais coordenadas conforme necessário
    ]

    for coord in coordenadas:
        folium.Marker(location=coord, popup="Local Fixo").add_to(mapa)

    st_folium = streamlit_folium.st_folium(mapa, width=800, height=600)

    con.commit()
    con.close()
