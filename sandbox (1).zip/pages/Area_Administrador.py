import streamlit as st
from mapa import *
from streamlit_option_menu import option_menu

st.set_page_config(page_title="Disk Denúncia",
                   page_icon="🖥️")

st.image('./images/logo-cyber-edux.jpeg')

#st.sidebar.image("./images/icone-cyber-edux.jpeg", use_column_width=True)
st.sidebar.header("Area do Administrador")

st.title("Area do Administrador")
st.write("Denunciar é fácil! Basta clicar no botão Fazer Denúncia, contar pra gente o que está acontecendo, e nós cuidaremos do resto. Vamos garantir que sua denúncia chegue às autoridades certas para que eles possam resolver o problema.")

# horizontal menu
selected2 = option_menu(None, ["Historico de denuncia", "Login Adm"],
                        icons=['a', "list-task"],
                        menu_icon="cast", default_index=0, orientation="horizontal")


if selected2 == "Historico de denuncia":
    exibir_mapa_reclamacoes()

elif selected2 == "Login Adm":
    st.text_input("Digite o usuario")
    st.text_input("Digite a Senha")
    st.button("Login")
